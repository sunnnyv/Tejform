export interface Trip {
  id: string;
  title: string;
  description: string;
  image: string;
}

export const trips: Trip[] = [
  {
    id: 'adventure',
    title: 'Adventure Travel',
    description: "Thrilling experiences in nature's playground",
    image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'wildlife',
    title: 'Wildlife Safari',
    description: 'Close encounters with magnificent creatures',
    image: 'https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'cultural',
    title: 'Cultural Tour',
    description: 'Immerse yourself in local traditions',
    image: 'https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'luxury',
    title: 'Luxury Retreat',
    description: 'Indulge in premium experiences',
    image: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=800&q=80'
  }
];