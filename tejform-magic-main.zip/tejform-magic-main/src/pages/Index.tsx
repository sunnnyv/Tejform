import React, { useState } from 'react';
import { TypeformQuestion } from '@/components/TypeformQuestion';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { submitTravelForm } from '@/services/mockService';
import type { TravelFormData } from '@/types/form';
import { TripCard } from '@/components/TripCard';
import { trips } from '@/data/trips';

const Index = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<TravelFormData>({
    name: '',
    email: '',
    whatsapp: '',
    tripType: '',
    requirements: '',
    referralSource: ''
  });
  const { toast } = useToast();

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleSubmit = async () => {
    try {
      await submitTravelForm(formData);
      toast({
        title: "Thank you for your submission!",
        description: "We'll get back to you shortly via WhatsApp.",
      });
      setFormData({
        name: '',
        email: '',
        whatsapp: '',
        tripType: '',
        requirements: '',
        referralSource: ''
      });
      setCurrentStep(0);
    } catch (error) {
      console.error('Error submitting form:', error);
      toast({
        title: "Error",
        description: "There was an error submitting your form. Please try again.",
        variant: "destructive",
      });
    }
  };

  const totalSteps = 7;

  return (
    <div className="min-h-screen w-full font-inter bg-gradient-to-br from-tej-secondary via-white to-tej-secondary relative">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTAiIGN5PSIxMCIgcj0iMiIgZmlsbD0icmdiYSg0LCA2OSwgMTc1LCAwLjEpIi8+PC9zdmc+')] opacity-50" />
      
      <div className="relative w-full">
        <AnimatePresence mode="wait">
          {currentStep === 0 && (
            <TypeformQuestion
              question=""
              isActive={true}
              onEnter={handleNext}
            >
              <div className="text-center space-y-6">
                <h1 className="font-cormorant text-5xl md:text-7xl text-tej-primary mb-4 animate-pulse">
                  TEJ
                </h1>
                <p className="text-lg text-gray-600 font-bold">The Ethereal Journey</p>
                <motion.button 
                  onClick={handleNext}
                  className="bg-tej-primary hover:bg-tej-primary/90 text-white px-8 py-6 text-lg rounded-xl transform transition-all duration-300 hover:scale-105 hover:shadow-xl font-bold"
                >
                  Get Started →
                </motion.button>
              </div>
            </TypeformQuestion>
          )}

          {currentStep === 1 && (
            <TypeformQuestion
              question="What's your name?"
              isActive={true}
              onEnter={handleNext}
            >
              <Input
                value={formData.name}
                onChange={(e) => {
                  setFormData({ ...formData, name: e.target.value });
                  if (e.target.value.length >= 2) {
                    setTimeout(handleNext, 500);
                  }
                }}
                placeholder="Type your name"
                className="text-lg py-6 px-4 rounded-xl border-2 focus:border-tej-primary transform transition-all duration-300 hover:shadow-lg"
                autoFocus
              />
            </TypeformQuestion>
          )}

          {currentStep === 2 && (
            <TypeformQuestion
              question="What's your email address?"
              isActive={true}
              onEnter={handleNext}
            >
              <Input
                value={formData.email}
                onChange={(e) => {
                  setFormData({ ...formData, email: e.target.value });
                  if (e.target.value.includes('@') && e.target.value.includes('.')) {
                    setTimeout(handleNext, 500);
                  }
                }}
                placeholder="Enter your email address"
                type="email"
                className="text-lg py-6 px-4 rounded-xl border-2 focus:border-tej-primary transform transition-all duration-300 hover:shadow-lg"
                autoFocus
              />
            </TypeformQuestion>
          )}

          {currentStep === 3 && (
            <TypeformQuestion
              question="What's your WhatsApp number?"
              isActive={true}
              onEnter={handleNext}
            >
              <Input
                value={formData.whatsapp}
                onChange={(e) => {
                  setFormData({ ...formData, whatsapp: e.target.value });
                  if (e.target.value.length >= 10) {
                    setTimeout(handleNext, 500);
                  }
                }}
                placeholder="Enter your WhatsApp number"
                type="tel"
                className="text-lg py-6 px-4 rounded-xl border-2 focus:border-tej-primary transform transition-all duration-300 hover:shadow-lg"
                autoFocus
              />
            </TypeformQuestion>
          )}

          {currentStep === 4 && (
            <TypeformQuestion
              question="What type of trip interests you?"
              isActive={true}
              onEnter={handleNext}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {trips.map((trip) => (
                  <TripCard
                    key={trip.id}
                    title={trip.title}
                    image={trip.image}
                    description={trip.description}
                    isSelected={formData.tripType === trip.id}
                    onClick={() => {
                      setFormData({ ...formData, tripType: trip.id });
                      setTimeout(handleNext, 500);
                    }}
                  />
                ))}
              </div>
            </TypeformQuestion>
          )}

          {currentStep === 5 && (
            <TypeformQuestion
              question="Tell us about your specific requirements"
              isActive={true}
              onEnter={handleNext}
            >
              <Textarea
                value={formData.requirements}
                onChange={(e) => {
                  setFormData({ ...formData, requirements: e.target.value });
                  if (e.target.value.length >= 10) {
                    setTimeout(handleNext, 500);
                  }
                }}
                placeholder="Share your travel preferences, dates, or any special requests..."
                className="text-lg py-4 px-4 rounded-xl border-2 focus:border-tej-primary min-h-[150px] transform transition-all duration-300 hover:shadow-lg"
                autoFocus
              />
            </TypeformQuestion>
          )}

          {currentStep === 6 && (
            <TypeformQuestion
              question="How did you hear about us?"
              isActive={true}
              onEnter={handleSubmit}
            >
              <Input
                value={formData.referralSource}
                onChange={(e) => {
                  setFormData({ ...formData, referralSource: e.target.value });
                  if (e.target.value.length >= 2) {
                    setTimeout(handleSubmit, 500);
                  }
                }}
                placeholder="Let us know where you found us"
                className="text-lg py-6 px-4 rounded-xl border-2 focus:border-tej-primary transform transition-all duration-300 hover:shadow-lg"
                autoFocus
              />
            </TypeformQuestion>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Index;