import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';

interface TripCardProps {
  title: string;
  image: string;
  description: string;
  isSelected: boolean;
  onClick: () => void;
}

export const TripCard = ({ title, image, description, isSelected, onClick }: TripCardProps) => {
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="cursor-pointer"
    >
      <Card 
        className={`relative overflow-hidden h-64 ${
          isSelected ? 'ring-4 ring-tej-primary' : ''
        }`}
        onClick={onClick}
      >
        {!imageLoaded && (
          <div className="absolute inset-0 bg-gray-200 animate-pulse" />
        )}
        <img 
          src={image}
          alt={title}
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          onLoad={() => setImageLoaded(true)}
        />
        <div className="absolute inset-0 bg-black/40" />
        <CardContent className="relative h-full flex flex-col justify-end p-6 text-white">
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          <p className="text-sm opacity-90">{description}</p>
          {isSelected && (
            <div className="absolute top-4 right-4 bg-tej-primary text-white p-2 rounded-full">
              ✓
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};