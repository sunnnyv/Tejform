import React, { forwardRef } from 'react';
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

interface TypeformQuestionProps {
  question: string;
  children: React.ReactNode;
  isActive: boolean;
  onEnter?: () => void;
}

export const TypeformQuestion = forwardRef<HTMLDivElement, TypeformQuestionProps>(({
  question,
  children,
  isActive,
  onEnter,
}, ref) => {
  React.useEffect(() => {
    if (isActive) {
      const handleKeyPress = (e: KeyboardEvent) => {
        if (e.key === 'Enter' && onEnter) {
          onEnter();
        }
      };
      window.addEventListener('keypress', handleKeyPress);
      return () => window.removeEventListener('keypress', handleKeyPress);
    }
  }, [isActive, onEnter]);

  const containerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut",
        staggerChildren: 0.1
      }
    },
    exit: {
      opacity: 0,
      y: -50,
      transition: {
        duration: 0.4
      }
    }
  };

  const childVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <motion.div
      ref={ref}
      variants={containerVariants}
      initial="hidden"
      animate={isActive ? "visible" : "hidden"}
      exit="exit"
      className={cn(
        "min-h-screen w-full flex items-stretch pointer-events-none",
        isActive && "pointer-events-auto"
      )}
    >
      {/* Left Panel with Image */}
      <div className="hidden lg:block w-1/2 bg-forest bg-cover bg-center relative">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="absolute inset-0 bg-tej-primary/30 backdrop-blur-sm"
        />
        <motion.div 
          variants={childVariants}
          className="absolute bottom-8 left-8 text-white"
        >
          <h1 className="font-cormorant text-5xl mb-4 tracking-wide">TEJ</h1>
          <p className="font-segoe text-xl">Your Travel Partner</p>
        </motion.div>
      </div>

      {/* Right Panel with Questions */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-white">
        <div className="max-w-xl w-full space-y-8">
          <motion.h2 
            variants={childVariants}
            className="text-3xl md:text-4xl font-segoe text-tej-primary mb-6 tracking-wide font-semibold"
          >
            {question}
          </motion.h2>
          <motion.div 
            variants={childVariants}
            className="space-y-4"
          >
            {children}
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
});

TypeformQuestion.displayName = "TypeformQuestion";