import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Facebook, Instagram, Linkedin, Twitter, Globe, Users, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase/client';

interface Lead {
  name: string;
  email: string;
  whatsapp: string;
  tripType: string;
  requirements: string;
  referralSource: string;
  createdAt: string;
}

const SOCIAL_MEDIA_COLORS = {
  facebook: '#4267B2',
  instagram: '#E1306C',
  linkedin: '#0077B5',
  twitter: '#1DA1F2',
  website: '#2E8B57',
  other: '#808080'
};

const getSocialMediaIcon = (source: string) => {
  const lowerSource = source.toLowerCase();
  if (lowerSource.includes('facebook')) return <Facebook className="w-4 h-4" />;
  if (lowerSource.includes('instagram')) return <Instagram className="w-4 h-4" />;
  if (lowerSource.includes('linkedin')) return <Linkedin className="w-4 h-4" />;
  if (lowerSource.includes('twitter')) return <Twitter className="w-4 h-4" />;
  if (lowerSource.includes('website')) return <Globe className="w-4 h-4" />;
  return <Users className="w-4 h-4" />;
};

const getSocialMediaColor = (source: string) => {
  const lowerSource = source.toLowerCase();
  if (lowerSource.includes('facebook')) return SOCIAL_MEDIA_COLORS.facebook;
  if (lowerSource.includes('instagram')) return SOCIAL_MEDIA_COLORS.instagram;
  if (lowerSource.includes('linkedin')) return SOCIAL_MEDIA_COLORS.linkedin;
  if (lowerSource.includes('twitter')) return SOCIAL_MEDIA_COLORS.twitter;
  if (lowerSource.includes('website')) return SOCIAL_MEDIA_COLORS.website;
  return SOCIAL_MEDIA_COLORS.other;
};

export const Dashboard = () => {
  const { data: leads = [], isLoading, error } = useQuery({
    queryKey: ['leads'],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from('submissions')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;

        return data.map(item => ({
          name: item.name || '',
          email: item.email || '',
          whatsapp: item.whatsapp || '',
          tripType: item.tripType || '',
          requirements: item.requirements || '',
          referralSource: item.referralSource || '',
          createdAt: item.created_at
        }));
      } catch (error) {
        console.error('Error fetching leads:', error);
        throw error;
      }
    }
  });

  const socialMediaStats = React.useMemo(() => {
    if (!leads?.length) return [];
    
    const stats = leads.reduce((acc: any, lead) => {
      const source = lead.referralSource.toLowerCase();
      const key = Object.keys(SOCIAL_MEDIA_COLORS).find(platform => 
        source.includes(platform)
      ) || 'other';
      
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(stats).map(([name, value]) => ({
      name,
      value
    }));
  }, [leads]);

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-red-500">Error loading dashboard data. Please try again later.</div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-tej-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 bg-gray-50 min-h-screen">
      <h1 className="text-2xl md:text-3xl font-bold mb-6 text-tej-primary">Lead Dashboard</h1>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="leads">All Leads</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Lead Sources
                </CardTitle>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={socialMediaStats}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {socialMediaStats.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={getSocialMediaColor(entry.name)} 
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {leads.slice(0, 5).map((lead) => (
                    <div key={lead.email} className="flex items-center gap-2 p-2 bg-white rounded-lg shadow-sm">
                      {getSocialMediaIcon(lead.referralSource)}
                      <div className="flex-1">
                        <p className="font-medium">{lead.name}</p>
                        <p className="text-sm text-gray-500">
                          {format(new Date(lead.createdAt), 'MMM dd, yyyy')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="leads">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {leads.map((lead) => (
              <Card key={lead.email} className="bg-white">
                <CardHeader className="flex flex-row items-center gap-2">
                  {getSocialMediaIcon(lead.referralSource)}
                  <CardTitle className="text-lg">{lead.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <p><strong>Email:</strong> {lead.email}</p>
                    <p><strong>WhatsApp:</strong> {lead.whatsapp}</p>
                    <p><strong>Trip Type:</strong> {lead.tripType}</p>
                    <p><strong>Requirements:</strong> {lead.requirements}</p>
                    <p><strong>Source:</strong> {lead.referralSource}</p>
                    <p><strong>Date:</strong> {format(new Date(lead.createdAt), 'MMM dd, yyyy')}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};