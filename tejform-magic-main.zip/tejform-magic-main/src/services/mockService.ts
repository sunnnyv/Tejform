import { supabase } from '@/lib/supabase/client';
import type { TravelFormData } from '@/types/form';

export const submitTravelForm = async (formData: TravelFormData) => {
  try {
    const { data, error } = await supabase
      .from('submissions')
      .insert([
        {
          ...formData,
          created_at: new Date().toISOString()
        }
      ])
      .select();

    if (error) throw error;
    return { id: data[0].id };
  } catch (error) {
    console.error('Error submitting form:', error);
    throw new Error('Failed to submit form');
  }
};