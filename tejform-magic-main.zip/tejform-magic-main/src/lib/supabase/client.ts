import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://anzbumxyxatgwnsdtnnv.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFuemJ1bXh5eGF0Z3duc2R0bm52Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDk4MzA0MDAsImV4cCI6MjAyNTQwNjQwMH0.Uu0GR5FRFGBjZFyZqbxC-_5Qm8uhQfcbhfcaR8Ot_Hs';

// Create Supabase client with explicit types
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});