export interface TravelFormData {
  name: string;
  email: string;
  whatsapp: string;
  tripType: string;
  requirements: string;
  referralSource: string;
}